const ProjectFiles = () => {
  return <div>In the process</div>;
};

export default ProjectFiles;
