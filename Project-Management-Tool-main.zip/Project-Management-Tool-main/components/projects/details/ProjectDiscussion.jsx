const ProjectDiscussion = () => {
  return <div>In the process</div>;
};

export default ProjectDiscussion;
